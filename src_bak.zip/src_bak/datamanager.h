#ifndef DATAMANAGER_H
#define DATAMANAGER_H

#include <flecs.h>
#include "dray.h"

typedef struct DataEntry {
    ecs_world_t *world;
    ecs_entity_t entity;
    void *data;
} DataEntry;

typedef struct DataManager {

} DataManager;

void dataentry_insert_data(int idx, void *data);
void dataentry_remove_data(int idx);

#endif /* DATAMANAGER_H */
